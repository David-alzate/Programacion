import time
for i in range(1, 10+1):
    for x in range(1, 10+1):
        print(f"{i}x{x} = {i*x}")
