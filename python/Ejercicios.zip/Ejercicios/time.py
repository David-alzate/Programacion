import time

for i in range(1, 16):
    print(i, "Colombia")
    time.sleep(1)

print("Fin del Programa")
