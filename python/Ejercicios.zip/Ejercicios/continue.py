var = 10
while var > 0:
    var -= 1 
    if var == 5:
        continue
    print(f"Current variable value :{var}")
    print("Good bye!")
