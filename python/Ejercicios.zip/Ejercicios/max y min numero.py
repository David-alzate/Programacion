n = []
for i in range (4):
    n = [int(input("Digite un numero"))] 
    i =+ 1


large_number = max (n)
min_number = max (n)

print(large_number)
print(min_number)





