potencia = 1 
for expo in range(16):
    print(f"2 a la potencia de {expo} es {potencia}")
    potencia = potencia * 2
    