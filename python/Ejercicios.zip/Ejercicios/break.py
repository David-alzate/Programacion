var = 10
while var > 0:
    print(f'Current variable value :{var}')
    var -= 1 
    if var == 5:
        break
print("Good bye!")
